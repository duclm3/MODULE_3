create
    definer = root@localhost procedure insert_Product(IN idd int, IN procode varchar(10), IN proname varchar(10),
                                                      IN proprice decimal, IN proamout smallint, IN prodescription text,
                                                      IN prostatus varchar(10))
begin
	DECLARE EXIT HANDLER FOR 1062
	BEGIN
		SELECT CONCAT('Duplicate key (',idd,')') AS message;
	END;
	insert into products values(idd,procode,proname,proprice,proamout,prodescription,prostatus);
    select 'Insert success'  AS message;
end;

