create
    definer = root@localhost procedure all_Product()
begin
	select * from products;
end;

