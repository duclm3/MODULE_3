create
    definer = root@localhost procedure update_product(IN idd int, IN procode varchar(10), IN proname varchar(10),
                                                      IN proprice decimal, IN proamout smallint, IN prodescription text,
                                                      IN prostatus varchar(10))
begin
	DECLARE EXIT HANDLER FOR sqlexception
	BEGIN
		SELECT "Can't not update" AS message;
	END;
	update products
	set productCode = procode,productName = proname,productPrice = proprice,
		productAmount = proamout,productDescription = prodescription,productStatus = prostatus
	where id = idd;    
    select 'Update success'  AS message;
end;

